import {defineCliConfig} from 'sanity/cli'

export default defineCliConfig({
  api: {
    projectId: '92vz1asq',
    dataset: 'production'
  },
  studioHost: 'therichgradstudent'
})
